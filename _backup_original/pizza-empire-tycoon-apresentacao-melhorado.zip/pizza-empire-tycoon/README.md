# Pizza Empire Tycoon

Jogo de gerenciamento de pizzaria para navegador/PC, em português brasileiro. Projeto original inspirado no gênero tycoon e em jogos de gerenciamento de restaurantes.

## Requisitos

- Windows 10 ou 11
- Node.js 20 LTS ou superior (inclui npm)
- Navegador atualizado (Chrome, Edge ou Firefox)

## Como instalar e iniciar

1. Instale o Node.js LTS em https://nodejs.org/ (marque a opção de adicionar ao PATH, se aparecer).
2. Extraia `pizza-empire-tycoon.zip` para uma pasta, por exemplo `C:\Jogos\pizza-empire-tycoon`.
3. Abra essa pasta no Explorador de Arquivos.
4. Clique na barra de endereço, digite `cmd` e pressione Enter.
5. No terminal que abrir, execute:

   ```bash
   npm install
   ```

6. Quando terminar, execute:

   ```bash
   npm run dev
   ```

7. Abra o endereço exibido no terminal, normalmente `http://localhost:5173`.
8. Para encerrar o jogo, volte ao terminal e pressione `Ctrl + C`.

## Como jogar

- **Mover:** use `W`, `A`, `S`, `D` ou as setas do teclado.
- **Mover com mouse:** clique em um ponto livre do piso para caminhar até lá.
- **Entregar pedido:** use o botão laranja “Preparar e entregar”. Cada pedido concluído rende moedas e conta para a evolução.
- **Melhorias:** use a aba Gestão para melhorar o forno, a velocidade e expandir o salão.
- **Equipe:** ao atingir o nível 2 (8 pedidos), a contratação é liberada.
- **Progresso:** acompanhe marcos de evolução; a franquia é liberada no nível 5.
- **Salvar:** o jogo salva automaticamente no navegador e também tem botão de salvamento manual.

## Criar uma versão de produção

Execute:

```bash
npm run build
```

Os arquivos prontos para publicação serão gerados na pasta `dist`. Para testar a versão de produção localmente:

```bash
npm run preview
```

## Interface

A interface recebeu uma revisão visual com hierarquia mais clara, cartões refinados, botões com estados visuais, melhor espaçamento, painel de gestão mais legível e ajustes responsivos para telas menores.

## Observações

- O progresso fica salvo no `localStorage` do navegador e no perfil de navegador usado. Limpar os dados do site apaga o progresso.
- A renda offline é calculada para funcionários contratados, com limite de 4 horas.
- Para jogar em outro computador, será necessário exportar/transferir o salvamento (a sincronização em nuvem não está incluída nesta versão).
- A versão entregue é uma primeira versão jogável: inclui cenário 3D isométrico, personagem controlável, pedidos, moedas, melhorias, desbloqueios, equipe, expansão, franquia e salvamento. Sistemas mais profundos de simulação de preparo individual, múltiplas cidades jogáveis e animações específicas de cada estação podem ser adicionados em versões futuras.


## Solução de problemas

- **`npm` não é reconhecido:** feche e reabra o Prompt de Comando após instalar o Node.js. Se persistir, reinstale o Node.js LTS habilitando a opção de adicionar ao PATH.
- **A porta 5173 já está em uso:** o Vite mostrará outra URL disponível no terminal; abra essa URL.
- **Tela em branco após alterações:** pare o servidor com `Ctrl + C`, rode `npm install` novamente e depois `npm run dev`.
- **O jogo não salva:** não use janela anônima e não limpe os dados do site. O salvamento é local ao navegador.


## Atualização da interface para apresentação

Esta edição reorganiza o jogo em um painel de simulação inspirado em jogos de gestão:
- faixa superior com saldo, clientes, satisfação, reputação e faturamento;
- mapa 3D isométrico da unidade e vizinhança;
- painel lateral com Loja, Restaurante, Finanças, Clientes, Equipe e Mural;
- catálogo de equipamentos e itens da pizzaria, com filtros e compra;
- controles de tempo, pausa e velocidade da simulação;
- barra inferior com ações de gestão e expansão;
- layout adaptável para telas menores.

Os indicadores do topo usam os dados atuais do jogo (saldo, pedidos, nível, equipe e faturamento acumulado). A simulação de horário e fluxo de clientes é ilustrativa; não representa uma contabilidade real por período.
