import { create } from 'zustand'

const SAVE_KEY = 'pizza-empire-save-v1'
const initial = {
  money: 0, lifetime: 0, level: 1, served: 0, reputation: 0,
  staff: 0, ovenLevel: 1, speedLevel: 1, tables: 2,
  unlocked: { kitchen: true, dining: true, staff: false, secondOven: false, franchise: false },
  lastSeen: Date.now(), tutorialDone: false
}
function loadSave() {
  try {
    const saved = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null')
    if (!saved) return initial
    const elapsed = Math.max(0, Math.min(4 * 60 * 60, (Date.now() - (saved.lastSeen || Date.now())) / 1000))
    const offline = Math.floor(elapsed * (saved.staff || 0) * 0.45)
    return { ...initial, ...saved, money: (saved.money || 0) + offline, lifetime: (saved.lifetime || 0) + offline, lastSeen: Date.now() }
  } catch { return initial }
}
export const useGame = create((set, get) => ({
  ...loadSave(),
  addMoney: (amount) => set(s => ({ money: s.money + amount, lifetime: s.lifetime + amount })),
  spend: (amount) => {
    if (get().money < amount) return false
    set(s => ({ money: s.money - amount }))
    return true
  },
  serve: () => set(s => {
    const served = s.served + 1
    const level = Math.max(s.level, 1 + Math.floor(served / 8))
    const unlocked = { ...s.unlocked, staff: level >= 2, secondOven: level >= 3, franchise: level >= 5 }
    return { served, level, reputation: Math.min(100, s.reputation + 1), money: s.money + 18 + s.ovenLevel * 3, lifetime: s.lifetime + 18 + s.ovenLevel * 3, unlocked }
  }),
  hire: () => {
    const s = get(), cost = 120 + s.staff * 100
    if (!s.unlocked.staff || !get().spend(cost)) return false
    set(v => ({ staff: v.staff + 1 }))
    return true
  },
  upgradeOven: () => {
    const s = get(), cost = 90 * s.ovenLevel
    if (!get().spend(cost)) return false
    set(v => ({ ovenLevel: v.ovenLevel + 1 }))
    return true
  },
  upgradeSpeed: () => {
    const s = get(), cost = 75 * s.speedLevel
    if (!get().spend(cost)) return false
    set(v => ({ speedLevel: v.speedLevel + 1 }))
    return true
  },
  expand: () => {
    const s = get(), cost = 450 + s.tables * 150
    if (!get().spend(cost)) return false
    set(v => ({ tables: v.tables + 2, unlocked: { ...v.unlocked, dining: true } }))
    return true
  },
  buyFranchise: () => {
    if (!get().unlocked.franchise || !get().spend(1800)) return false
    set(s => ({ money: s.money, level: s.level + 1, served: 0, reputation: 0, staff: 0, tables: 2, ovenLevel: 1, speedLevel: 1, unlocked: { ...s.unlocked, franchise: false } }))
    return true
  },
  markTutorial: () => set({ tutorialDone: true }),
  save: () => {
    const s = get()
    const data = { ...s, lastSeen: Date.now() }
    delete data.addMoney; delete data.spend; delete data.serve; delete data.hire
    delete data.upgradeOven; delete data.upgradeSpeed; delete data.expand; delete data.buyFranchise
    delete data.markTutorial; delete data.save
    localStorage.setItem(SAVE_KEY, JSON.stringify(data))
  },
  reset: () => { localStorage.removeItem(SAVE_KEY); set({ ...initial, lastSeen: Date.now() }) }
}))
