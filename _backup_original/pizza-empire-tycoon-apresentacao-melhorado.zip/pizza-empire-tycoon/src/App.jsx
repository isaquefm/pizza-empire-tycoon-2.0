import React, { Suspense, useEffect, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { ContactShadows, Float, RoundedBox, Text } from '@react-three/drei'
import * as THREE from 'three'
import {
  Pizza, Coins, Users, Star, TrendingUp, ChefHat, ShoppingCart, Store,
  Utensils, Flame, Armchair, Refrigerator, Coffee, Building2, Wallet,
  ClipboardList, Settings, Play, Pause, FastForward, Volume2, Save,
  Maximize, ZoomIn, ZoomOut, Wrench, Paintbrush, Expand, ArrowUp,
  Lock, CheckCircle2, Clock3, Heart, Sparkles, CalendarDays, Crown,
  RotateCcw, Info, Package, BadgeDollarSign, ChartNoAxesCombined
} from 'lucide-react'
import { useGame } from './store'

const fmt = n => Math.floor(n).toLocaleString('pt-BR')
const clamp = (n,a,b) => Math.max(a,Math.min(b,n))

function Ground() {
  return <group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.09,0]} receiveShadow>
      <planeGeometry args={[28,22]}/><meshStandardMaterial color="#a9c2a7"/>
    </mesh>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.075,0]}>
      <planeGeometry args={[13.8,12.2]}/><meshStandardMaterial color="#d6c7b5"/>
    </mesh>
    {Array.from({length:8},(_,i)=><mesh key={i} rotation={[-Math.PI/2,0,0]} position={[-6.5+i*1.85,-.06,0]}>
      <planeGeometry args={[.025,12]}/><meshBasicMaterial color="#c4b39f"/>
    </mesh>)}
    <mesh position={[0,.35,-6.2]} castShadow><boxGeometry args={[14,.8,.25]}/><meshStandardMaterial color="#e8e0d2"/></mesh>
    <mesh position={[-6.9,.65,0]}><boxGeometry args={[.22,1.3,12.4]}/><meshStandardMaterial color="#e8e0d2"/></mesh>
    <mesh position={[6.9,.65,0]}><boxGeometry args={[.22,1.3,12.4]}/><meshStandardMaterial color="#e8e0d2"/></mesh>
  </group>
}
function Street({position=[0,0,0],rotation=0,length=27}) {
  return <group position={position} rotation={[0,rotation,0]}>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.04,0]}><planeGeometry args={[length,2.5]}/><meshStandardMaterial color="#8d91a7"/></mesh>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.025,0]}><planeGeometry args={[length,.035]}/><meshBasicMaterial color="#e9e5d8"/></mesh>
    {Array.from({length:Math.floor(length/2)},(_,i)=><mesh key={i} rotation={[-Math.PI/2,0,0]} position={[-length/2+1+i*2,-.018,0]}><planeGeometry args={[.9,.045]}/><meshBasicMaterial color="#e9e5d8"/></mesh>)}
  </group>
}
function House({position,color='#b8b2c4',roof='#a65f51',scale=1}) {
  return <group position={position} scale={scale}>
    <mesh position={[0,.65,0]} castShadow><boxGeometry args={[1.8,1.3,1.7]}/><meshStandardMaterial color={color}/></mesh>
    <mesh position={[0,1.45,0]} rotation={[0,Math.PI/4,0]} castShadow><coneGeometry args={[1.42,.85,4]}/><meshStandardMaterial color={roof}/></mesh>
    <mesh position={[0,.55,.86]}><boxGeometry args={[.42,.55,.035]}/><meshStandardMaterial color="#9fc2cb"/></mesh>
    <mesh position={[-.58,.75,.87]}><boxGeometry args={[.32,.34,.035]}/><meshStandardMaterial color="#e8c78a"/></mesh>
  </group>
}
function Tree({position}) {
  return <group position={position}>
    <mesh position={[0,.24,0]}><cylinderGeometry args={[.09,.13,.48,7]}/><meshStandardMaterial color="#8a684b"/></mesh>
    {[0,1,2].map(i=><mesh key={i} position={[Math.cos(i*2.1)*.12,.62+i*.12,Math.sin(i*2.1)*.12]}><dodecahedronGeometry args={[.32-i*.025,1]}/><meshStandardMaterial color={i===1?'#6eaa76':'#78b481'}/></mesh>)}
  </group>
}
function Label({children,position=[0,2,0],color='#36465b'}) {
  return <Text position={position} fontSize={.19} color={color} anchorX="center" outlineWidth={.012} outlineColor="#fff">{children}</Text>
}
function Counter({position,label,color='#3b82aa',size=[1.7,.72,.72]}) {
  return <group position={position}>
    <RoundedBox args={size} radius={.08} position={[0,size[1]/2,0]} castShadow><meshStandardMaterial color={color}/></RoundedBox>
    <mesh position={[0,size[1]+.06,0]}><boxGeometry args={[size[0]*.78,.1,size[2]*.72]}/><meshStandardMaterial color="#f7dfb8"/></mesh>
    <Label position={[0,size[1]+.37,.42]}>{label}</Label>
  </group>
}
function Oven({position,level}) {
  return <group position={position}>
    <RoundedBox args={[1.15,1.1,.95]} radius={.1} position={[0,.55,0]} castShadow><meshStandardMaterial color="#c95e47"/></RoundedBox>
    <mesh position={[0,.5,.49]}><boxGeometry args={[.76,.48,.035]}/><meshStandardMaterial color="#27394b" emissive="#ef8742" emissiveIntensity={.6}/></mesh>
    <mesh position={[0,.88,.51]}><boxGeometry args={[.82,.07,.05]}/><meshStandardMaterial color="#f3c16c"/></mesh>
    <Label position={[0,1.28,.08]}>FORNO {level}</Label>
  </group>
}
function Table({position}) {
  return <group position={position}>
    <mesh position={[0,.48,0]} castShadow><cylinderGeometry args={[.48,.48,.12,20]}/><meshStandardMaterial color="#e5a85e"/></mesh>
    <mesh position={[0,.22,0]}><cylinderGeometry args={[.08,.1,.4,10]}/><meshStandardMaterial color="#976342"/></mesh>
    {[0,1,2,3].map(i=><mesh key={i} position={[Math.cos(i*Math.PI/2)*.68,.2,Math.sin(i*Math.PI/2)*.68]} castShadow><boxGeometry args={[.3,.34,.3]}/><meshStandardMaterial color="#508a91"/></mesh>)}
    <mesh position={[0,.55,0]}><cylinderGeometry args={[.15,.15,.025,20]}/><meshStandardMaterial color="#d95f43"/></mesh>
  </group>
}
function Person({position=[0,0,0],color='#d69a52',chef=false,scale=1}) {
  return <group position={position} scale={scale}>
    <mesh position={[0,.38,0]} castShadow><capsuleGeometry args={[.17,.34,4,8]}/><meshStandardMaterial color={color}/></mesh>
    <mesh position={[0,.78,0]} castShadow><sphereGeometry args={[.18,12,10]}/><meshStandardMaterial color="#e9b991"/></mesh>
    {chef&&<mesh position={[0,.98,0]}><cylinderGeometry args={[.18,.2,.12,12]}/><meshStandardMaterial color="#fff5e8"/></mesh>}
    <mesh position={[.06,.8,.15]}><sphereGeometry args={[.018,6,6]}/><meshBasicMaterial color="#253344"/></mesh>
    <mesh position={[-.06,.8,.15]}><sphereGeometry args={[.018,6,6]}/><meshBasicMaterial color="#253344"/></mesh>
    <mesh position={[0,.1,0]}><boxGeometry args={[.26,.17,.3]}/><meshStandardMaterial color="#394d61"/></mesh>
  </group>
}
function Player() {
  const ref=useRef(),target=useRef(new THREE.Vector3(0,0,1.8)),keys=useRef({})
  const speed=useGame(s=>s.speedLevel)
  const {camera,raycaster,pointer}=useThree()
  useEffect(()=>{
    const down=e=>keys.current[e.key.toLowerCase()]=true
    const up=e=>keys.current[e.key.toLowerCase()]=false
    window.addEventListener('keydown',down);window.addEventListener('keyup',up)
    return()=>{window.removeEventListener('keydown',down);window.removeEventListener('keyup',up)}
  },[])
  useEffect(()=>{
    const click=()=>{raycaster.setFromCamera(pointer,camera);const plane=new THREE.Plane(new THREE.Vector3(0,1,0),0),p=new THREE.Vector3();if(raycaster.ray.intersectPlane(plane,p))target.current.set(clamp(p.x,-5.8,5.8),0,clamp(p.z,-4.8,5))}
    window.addEventListener('pizza-ground-click',click);return()=>window.removeEventListener('pizza-ground-click',click)
  },[camera,raycaster,pointer])
  useFrame((_,dt)=>{
    if(!ref.current)return
    const k=keys.current,v=new THREE.Vector3((k.d||k.arrowright?1:0)-(k.a||k.arrowleft?1:0),0,(k.s||k.arrowdown?1:0)-(k.w||k.arrowup?1:0))
    if(v.lengthSq()){v.normalize();target.current.copy(ref.current.position).add(v.multiplyScalar(2))}
    const d=target.current.clone().sub(ref.current.position);d.y=0
    if(d.length()>.09){d.normalize();ref.current.position.addScaledVector(d,dt*(2.3+speed*.24));ref.current.rotation.y=Math.atan2(d.x,d.z)}
  })
  return <group ref={ref} position={[0,0,2]}><Person color="#2e7fc1" chef/></group>
}
function RestaurantWorld({customers,staff,ovenLevel}) {
  const {camera}=useThree()
  useEffect(()=>{camera.position.set(10,13,14);camera.lookAt(0,0,0)},[camera])
  return <group>
    <ambientLight intensity={1.15}/>
    <directionalLight position={[6,12,5]} intensity={2} castShadow shadow-mapSize={[2048,2048]}/>
    <Ground/>
    <Street position={[0,0,-8.2]} rotation={0}/><Street position={[0,0,8.2]} rotation={0}/>
    <Street position={[-10,0,0]} rotation={Math.PI/2} length={19}/><Street position={[10,0,0]} rotation={Math.PI/2} length={19}/>
    {Array.from({length:5},(_,i)=><House key={'h'+i} position={[-8+i*4,0,-10.3]} color={i%2?'#c4b7c7':'#d4c5ac'} roof={i%2?'#665a7d':'#a45f51'} scale={.9}/>)}
    {Array.from({length:5},(_,i)=><House key={'b'+i} position={[-8+i*4,0,10.3]} color="#c8c2b2" roof="#6c617f" scale={.9}/>)}
    {Array.from({length:8},(_,i)=><Tree key={'t'+i} position={[-6.5+(i%4)*4.2,0,-6.8+Math.floor(i/4)*13.6]}/>)}
    {/* Lote reservado para futuras ampliações */}
    <mesh rotation={[-Math.PI/2,0,0]} position={[5.15,-.025,-1.4]}><planeGeometry args={[3.1,4.2]}/><meshStandardMaterial color="#a9c6a3"/></mesh>
    <mesh position={[5.15,.04,-1.4]}><boxGeometry args={[3.1,.08,4.2]}/><meshStandardMaterial color="#8eaa89"/></mesh>
    <Label position={[5.15,.5,-1.4]} color="#536d57">EXPANSÃO</Label>
    <group>
      <mesh position={[0,.08,0]}><boxGeometry args={[13.5,.18,12]}/><meshStandardMaterial color="#d7c9b6"/></mesh>
      {Array.from({length:6},(_,i)=><mesh key={i} position={[-5.4+i*2.16,.18,0]}><boxGeometry args={[.025,.02,11.8]}/><meshBasicMaterial color="#c2b29d"/></mesh>)}
      <mesh position={[0,.55,-5.85]} castShadow><boxGeometry args={[13.5,1,.25]}/><meshStandardMaterial color="#e8dfd2"/></mesh>
      <Counter position={[-4.6,.18,-3.3]} label="PEDIDOS"/>
      <Oven position={[-1.6,.18,-4.3]} level={ovenLevel}/>
      <Counter position={[1.2,.18,-4.3]} label="MONTAGEM" color="#d28a48"/>
      <Counter position={[4.6,.18,-3.1]} label="RETIRADA" color="#398a80"/>
      <Counter position={[-4.6,.18,2.1]} label="BEBIDAS" color="#5b91b0" size={[1.3,.65,.65]}/>
      {[[-3.4,1.5],[0,1.5],[3.4,1.5],[-3.4,4],[0,4],[3.4,4]].map((p,i)=><Table key={i} position={[p[0],.18,p[1]]}/>)}
      {Array.from({length:Math.min(customers,6)},(_,i)=><group key={'c'+i} position={[-5+(i%3)*2.3,0,-1.1+Math.floor(i/3)*1.25]}><Person color={['#dc9660','#7da9a0','#a48ac3','#d4b46b','#d17b78','#7b9bc4'][i]}/><Float speed={1.3} floatIntensity={.12}><mesh position={[0,1.2,0]}><sphereGeometry args={[.12,10,8]}/><meshBasicMaterial color="#fff5d7"/></mesh></Float></group>)}
      {Array.from({length:staff},(_,i)=><Person key={'s'+i} position={[2.6+(i%2)*.7,0,-.5+Math.floor(i/2)*1.1]} color="#6d9c68" chef scale={.9}/>)}
      <Player/>
    </group>
    <ContactShadows position={[0,-.02,0]} opacity={.28} scale={22} blur={2.6}/>
  </group>
}
function World({customers,staff,ovenLevel}) {
  return <Canvas shadows camera={{position:[10,13,14],fov:36}} onPointerMissed={()=>{}}>
    <color attach="background" args={['#aebfae']}/>
    <Suspense fallback={null}><RestaurantWorld customers={customers} staff={staff} ovenLevel={ovenLevel}/></Suspense>
  </Canvas>
}
const shopItems=[
  {id:'rack',name:'Bancada de preparo',type:'Cozinha',price:250,desc:'Mais espaço para montar pizzas e organizar ingredientes.',detail:'Capacidade +2 pedidos',icon:Utensils,tag:'MAIS VENDIDO'},
  {id:'oven',name:'Forno profissional',type:'Máquinas',price:90,desc:'Assa pizzas com mais velocidade e aumenta o valor dos pedidos.',detail:'Rendimento +3 moedas',icon:Flame,tag:'RECOMENDADO'},
  {id:'drink',name:'Bebedouro',type:'Conforto',price:150,desc:'Água geladinha para clientes e equipe durante o expediente.',detail:'Satisfação +5',icon:Coffee},
  {id:'fridge',name:'Geladeira industrial',type:'Cozinha',price:400,desc:'Armazene ingredientes frescos e reduza o desperdício.',detail:'Estoque +20%',icon:Refrigerator},
  {id:'table',name:'Mesa familiar',type:'Salão',price:750,desc:'Acomoda mais clientes e amplia a capacidade do salão.',detail:'Capacidade +4 lugares',icon:Armchair},
  {id:'sign',name:'Fachada iluminada',type:'Decoração',price:320,desc:'Deixe sua pizzaria mais convidativa e reconhecível.',detail:'Reputação +3',icon:Sparkles}
]
function App() {
  const game=useGame()
  const [tab,setTab]=useState('Loja'),[category,setCategory]=useState('Tudo'),[notice,setNotice]=useState('Sua pizzaria está aberta! Os clientes estão chegando.'),[orders,setOrders]=useState(2),[customers,setCustomers]=useState(4),[paused,setPaused]=useState(false),[speed,setSpeed]=useState(1),[showSettings,setShowSettings]=useState(false)
  const [day,setDay]=useState(1),[clock,setClock]=useState(9*60)
  const [owned,setOwned]=useState(['starter'])
  useEffect(()=>{const id=setInterval(()=>{if(!paused){setClock(c=>{if(c>=22*60){setDay(d=>d+1);return 8*60}return c+2*speed});setOrders(o=>Math.min(8,o+1));setCustomers(c=>Math.min(8,Math.max(2,c+(Math.random()>.52?1:-1))))}},1800);return()=>clearInterval(id)},[paused,speed])
  useEffect(()=>{game.save();const id=setInterval(()=>game.save(),5000);return()=>clearInterval(id)},[])
  useEffect(()=>{const f=()=>game.save();window.addEventListener('beforeunload',f);return()=>window.removeEventListener('beforeunload',f)},[])
  const satisfaction=Math.min(99,Math.round(42+game.reputation*.55+game.staff*2))
  const revenue=Math.max(0,game.lifetime)
  const time=`${String(Math.floor(clock/60)).padStart(2,'0')}:${String(clock%60).padStart(2,'0')}`
  const serve=()=>{if(paused){setNotice('Retome o expediente para atender pedidos.');return}if(!orders){setNotice('Nenhum pedido aguardando.');return}game.serve();setOrders(n=>n-1);setNotice(`Pedido entregue! +${18+game.ovenLevel*3} moedas no caixa.`)}
  const buy=(item)=>{if(owned.includes(item.id)){setNotice('Este item já foi adquirido.');return}if(item.id==='oven'){if(game.upgradeOven()){setOwned(v=>[...v,item.id]);setNotice('Forno profissional aprimorado!')}else setNotice('Saldo insuficiente para aprimorar o forno.');return}if(item.id==='table'){if(game.expand()){setOwned(v=>[...v,item.id]);setNotice('Salão ampliado! Novas mesas disponíveis.')}else setNotice('Saldo insuficiente para ampliar o salão.');return}if(game.spend(item.price)){setOwned(v=>[...v,item.id]);setNotice(`${item.name} comprado e adicionado à pizzaria!`)}else setNotice('Saldo insuficiente para esta compra.')}
  const hire=()=>{const ok=game.hire();setNotice(ok?'Novo funcionário contratado!':'Equipe bloqueada ou saldo insuficiente.')}
  const categories=['Tudo','Cozinha','Máquinas','Salão','Conforto','Decoração']
  const filtered=shopItems.filter(x=>category==='Tudo'||x.type===category)
  const nav=[['Loja',ShoppingCart],['Restaurante',Store],['Finanças',ChartNoAxesCombined],['Clientes',Users],['Equipe',ChefHat],['Mural',ClipboardList]]
  const stars=Math.max(1,Math.min(5,Math.ceil((satisfaction/100)*5)))
  return <main className="tycoon-app">
    <header className="sim-topbar">
      <div className="sim-brand"><div className="sim-logo"><Pizza size={22}/></div><div><b>Pizza Empire</b><small>TYCOON · UNIDADE 01</small></div></div>
      <div className="top-kpis">
        <div className="kpi"><span className="kpi-icon"><Wallet/></span><div><small>SALDO</small><b>R$ {fmt(game.money)}</b></div></div>
        <div className="kpi"><span className="kpi-icon"><Users/></span><div><small>CLIENTES</small><b>{customers}</b><em>{game.served} atendidos</em></div></div>
        <div className="kpi"><span className="kpi-icon"><Heart/></span><div><small>SATISFAÇÃO</small><b>{satisfaction}%</b></div></div>
        <div className="kpi reputation"><span className="kpi-icon"><Star/></span><div><small>REPUTAÇÃO</small><b>{'★'.repeat(stars)}<span>{'☆'.repeat(5-stars)}</span></b></div></div>
        <div className="kpi revenue"><span className="kpi-icon"><TrendingUp/></span><div><small>FATURAMENTO TOTAL</small><b>R$ {fmt(revenue)}</b><em>+R$ {fmt(18+game.ovenLevel*3)} por pedido</em></div></div>
      </div>
      <div className="sim-controls">
        <div className="sim-date"><CalendarDays size={13}/> Dia {day} · Ano 1 <span>{time}</span></div>
        <div className="speed-controls">
          <button title="Pausar/continuar" onClick={()=>setPaused(v=>!v)}>{paused?<Play size={14}/>:<Pause size={14}/>}</button>
          {[1,2,4].map(n=><button key={n} className={speed===n?'chosen':''} onClick={()=>{setSpeed(n);setPaused(false)}}>×{n}</button>)}
        </div>
      </div>
      <div className="profile-tools">
        <span className="profile-pill"><i/> Gerente</span>
        <button title="Salvar" onClick={()=>{game.save();setNotice('Progresso salvo com sucesso!')}}><Save/></button>
        <button title="Configurações" onClick={()=>setShowSettings(v=>!v)}><Settings/></button>
      </div>
    </header>
    <div className="sim-layout">
      <section className="map-panel">
        <div className="map-caption"><div><span>SEU NEGÓCIO</span><b>Rua da Pizza · Unidade 01</b></div><div className="live-open"><i/> {paused?'PAUSADO':'FUNCIONANDO'}</div></div>
        <div className="sim-world"><World customers={customers} staff={game.staff} ovenLevel={game.ovenLevel}/><div className="world-legend"><span><i className="legend-client"/> Clientes</span><span><i className="legend-staff"/> Equipe</span><span><i className="legend-you"/> Você</span></div><div className="world-controls"><button title="Aproximar"><ZoomIn/></button><button title="Afastar"><ZoomOut/></button><button title="Tela cheia" onClick={()=>document.querySelector('.sim-world')?.requestFullscreen?.()}><Maximize/></button></div></div>
        <div className="map-bottom">
          <div className="queue-summary"><div className="queue-icon"><Pizza/></div><div><small>PEDIDOS NA FILA</small><b>{orders} <em>aguardando preparo</em></b></div></div>
          <div className="map-actions">
            <button onClick={()=>setNotice('Modo de edição: escolha melhorias na Loja para personalizar sua pizzaria.')}><Paintbrush/> Editar</button>
            <button onClick={()=>setNotice('Manutenção em dia! Seus equipamentos estão operacionais.')}><Wrench/> Manutenção</button>
            <button onClick={()=>setTab('Restaurante')}><Building2/> Reformar</button>
            <button onClick={()=>setTab('Loja')}><Expand/> Ampliar</button>
            <button className="upgrade-all" onClick={()=>{if(game.money>=500){game.spend(500);game.upgradeOven();setNotice('Melhorias gerais aplicadas!')}else setNotice('São necessárias R$ 500 para melhorar tudo.')}}><ArrowUp/> Melhorar tudo (R$ 500)</button>
          </div>
        </div>
      </section>
      <aside className="sim-sidebar">
        <nav className="sim-nav">{nav.map(([name,Icon])=><button key={name} className={tab===name?'selected':''} onClick={()=>setTab(name)}><Icon/><span>{name}</span>{name==='Loja'&&<i className="nav-dot"/>}</button>)}</nav>
        <div className="sidebar-content">
          {tab==='Loja'&&<>
            <div className="section-heading"><div><small>CATÁLOGO DA PIZZARIA</small><b>Loja de equipamentos</b></div><span className="store-balance"><Coins size={13}/> R$ {fmt(game.money)}</span></div>
            <div className="category-list">{categories.map(c=><button key={c} className={category===c?'on':''} onClick={()=>setCategory(c)}>{c}</button>)}</div>
            <div className="product-list">{filtered.map(item=>{const Icon=item.icon,has=owned.includes(item.id);return <article className="product-card" key={item.id}>
              {item.tag&&<span className="product-tag">{item.tag}</span>}
              <div className="product-icon"><Icon/></div>
              <div className="product-main"><div className="product-name">{item.name}</div><div className="product-type">{item.type} · {item.id==='oven'?'Equipamento 2×2':'Item de operação'}</div><p>{item.desc}</p><small>{item.detail}</small></div>
              <div className="product-buy"><b>R$ {fmt(item.price)}</b><button disabled={has} onClick={()=>buy(item)}>{has?<><CheckCircle2 size={12}/> Comprado</>:'Comprar'}</button></div>
            </article>})}</div>
          </>}
          {tab==='Restaurante'&&<><div className="section-heading"><div><small>OPERAÇÃO E ESTRUTURA</small><b>Seu restaurante</b></div></div><div className="overview-grid"><div><Utensils/><b>{game.tables}</b><small>Mesas disponíveis</small></div><div><Flame/><b>Nível {game.ovenLevel}</b><small>Forno principal</small></div><div><Pizza/><b>{game.served}</b><small>Pedidos entregues</small></div><div><Star/><b>{game.level}</b><small>Nível da unidade</small></div></div><div className="info-card"><b>Capacidade do restaurante</b><p>Amplie o salão para receber mais clientes e investir em novos equipamentos para sua cozinha.</p><button onClick={()=>{if(game.money>=450+game.tables*150){game.expand();setNotice('Salão ampliado! +2 mesas.')}else setNotice('Saldo insuficiente para ampliar o salão.')}}>Ampliar salão · R$ {fmt(450+game.tables*150)}</button></div><div className="info-card"><b>Manutenção preventiva</b><p>Equipamentos revisados. Mantenha seus fornos e estações em boas condições para acelerar o atendimento.</p><button className="secondary" onClick={()=>setNotice('Manutenção concluída. Tudo funcionando perfeitamente!')}>Realizar manutenção gratuita</button></div></>}
          {tab==='Finanças'&&<><div className="section-heading"><div><small>CONTROLE FINANCEIRO</small><b>Finanças da pizzaria</b></div></div><div className="finance-hero"><small>SALDO DISPONÍVEL</small><strong>R$ {fmt(game.money)}</strong><span>Faturamento acumulado: R$ {fmt(revenue)}</span></div><div className="finance-row"><span>Receita por pedido</span><b>R$ {18+game.ovenLevel*3}</b></div><div className="finance-row"><span>Pedidos concluídos</span><b>{game.served}</b></div><div className="finance-row"><span>Investimento em forno</span><b>Nível {game.ovenLevel}</b></div><div className="info-card"><b>Dica de gestão</b><p>Reinvista parte do faturamento em equipamentos e equipe. Melhorias aumentam a capacidade de atendimento e o crescimento do negócio.</p></div></>}
          {tab==='Clientes'&&<><div className="section-heading"><div><small>RELACIONAMENTO</small><b>Experiência dos clientes</b></div></div><div className="customer-score"><Heart/><strong>{satisfaction}%</strong><span>Satisfação estimada</span></div><div className="finance-row"><span>Clientes no restaurante</span><b>{customers}</b></div><div className="finance-row"><span>Pedidos na fila</span><b>{orders}</b></div><div className="finance-row"><span>Reputação</span><b>{stars}/5 estrelas</b></div><div className="info-card"><b>Como melhorar?</b><p>Atenda os pedidos rapidamente, invista em conforto e amplie a equipe para reduzir o tempo de espera.</p></div></>}
          {tab==='Equipe'&&<><div className="section-heading"><div><small>GESTÃO DE PESSOAS</small><b>Sua equipe</b></div></div><div className="team-summary"><div className="team-avatar"><ChefHat/></div><div><b>{game.staff} funcionários contratados</b><small>Equipe operacional da unidade</small></div></div><div className="info-card"><b>Auxiliar de cozinha</b><p>Ajuda na operação e gera renda enquanto você joga, inclusive durante períodos offline.</p><button disabled={!game.unlocked.staff} onClick={hire}>{game.unlocked.staff?`Contratar · R$ ${fmt(120+game.staff*100)}`:`Desbloqueia no nível 2`}</button></div><div className="finance-row"><span>Próximo desbloqueio</span><b>{game.unlocked.staff?'Disponível':'Nível 2'}</b></div></>}
          {tab==='Mural'&&<><div className="section-heading"><div><small>AVISOS DA UNIDADE</small><b>Mural de gestão</b></div></div><div className="notice-card"><Sparkles/><div><b>Bem-vindo ao Pizza Empire!</b><p>Comece atendendo pedidos, depois invista em equipamentos para desenvolver sua unidade.</p></div></div><div className="notice-card"><TrendingUp/><div><b>Meta de crescimento</b><p>Entregue 8 pedidos para desbloquear a contratação do primeiro funcionário.</p></div></div><div className="notice-card"><Crown/><div><b>Sonho de franquia</b><p>Alcance o nível 5 para liberar a expansão para novas unidades.</p></div></div></>}
        </div>
        <div className="sidebar-notice"><span className="notice-led"/>{notice}</div>
      </aside>
    </div>
    <footer className="sim-footer"><span>🍕 PIZZA EMPIRE TYCOON <i>·</i> SIMULADOR DE GESTÃO DE PIZZARIA</span><span><i className="notice-led"/> Salvamento automático ativo</span><button onClick={()=>{if(confirm('Deseja apagar o progresso e iniciar uma nova pizzaria?')){game.reset();setOwned(['starter']);setNotice('Nova pizzaria iniciada. Boa sorte!')}}}><RotateCcw size={12}/> Reiniciar</button></footer>
    {showSettings&&<div className="settings-pop"><div><b>Configurações rápidas</b><button onClick={()=>setShowSettings(false)}>×</button></div><p>O progresso é salvo automaticamente neste navegador.</p><button onClick={()=>{game.save();setNotice('Jogo salvo!');setShowSettings(false)}}><Save size={14}/> Salvar agora</button><button onClick={()=>{setPaused(v=>!v);setShowSettings(false)}}>{paused?<Play size={14}/>:<Pause size={14}/>} {paused?'Retomar expediente':'Pausar expediente'}</button></div>}
    <button className="serve-fab" onClick={serve}><Pizza size={17}/> ENTREGAR PEDIDO <b>{orders}</b></button>
  </main>
}
export default App
